package dev.akhud.armourhud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ElytraItem;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ArmourHudClient implements ClientModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            Minecraft.getInstance().gameDirectory.toPath().resolve("config/armourhud.json");

    private static HudConfig config = new HudConfig();

    @Override
    public void onInitializeClient() {
        loadConfig();
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath("armourhud", "durability_hud"),
                ArmourHudClient::renderHud
        );
    }

    private static void renderHud(GuiGraphics graphics, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft minecraft = Minecraft.getInstance();
        if (!config.enabled || minecraft.player == null || minecraft.options.hideGui) {
            return;
        }

        List<String> lines = new ArrayList<>();
        addStackLine(lines, "Helmet", minecraft.player.getItemBySlot(EquipmentSlot.HEAD));

        ItemStack chest = minecraft.player.getItemBySlot(EquipmentSlot.CHEST);
        if (!chest.isEmpty()) {
            String chestLabel = chest.getItem() instanceof ElytraItem ? "Elytra" : "Chestplate";
            addStackLine(lines, chestLabel, chest);
        }

        addStackLine(lines, "Leggings", minecraft.player.getItemBySlot(EquipmentSlot.LEGS));
        addStackLine(lines, "Boots", minecraft.player.getItemBySlot(EquipmentSlot.FEET));

        // Main hand and offhand cover swords, axes, pickaxes, bows, crossbows,
        // tridents, fishing rods, shears, and other damageable items.
        addStackLine(lines, "Main hand", minecraft.player.getMainHandItem());
        addStackLine(lines, "Off hand", minecraft.player.getOffhandItem());

        if (lines.isEmpty()) {
            return;
        }

        int x = Math.max(0, config.x);
        int y = Math.max(0, config.y);
        int width = 0;
        for (String line : lines) {
            width = Math.max(width, minecraft.font.width(line));
        }
        width += 12;
        int lineHeight = 12;
        int height = lines.size() * lineHeight + 8;

        graphics.fill(x, y, x + width, y + height, config.backgroundColor);
        for (int i = 0; i < lines.size(); i++) {
            graphics.drawString(minecraft.font, lines.get(i), x + 6, y + 5 + i * lineHeight,
                    config.textColor, true);
        }
    }

    private static void addStackLine(List<String> lines, String label, ItemStack stack) {
        if (stack.isEmpty() || !stack.isDamageableItem() || stack.getMaxDamage() <= 0) {
            return;
        }
        lines.add(label + ": " + formatDurability(stack));
    }

    private static String formatDurability(ItemStack stack) {
        int max = stack.getMaxDamage();
        int remaining = Math.max(0, max - stack.getDamageValue());
        int percent = Math.round(remaining * 100.0f / max);

        return switch (config.displayMode.toUpperCase()) {
            case "NUMBER" -> remaining + "/" + max;
            case "PERCENT" -> percent + "%";
            default -> remaining + "/" + max + " (" + percent + "%)";
        };
    }

    private static void loadConfig() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            if (Files.exists(CONFIG_PATH)) {
                HudConfig loaded = GSON.fromJson(Files.readString(CONFIG_PATH), HudConfig.class);
                if (loaded != null) {
                    config = loaded;
                }
            } else {
                Files.writeString(CONFIG_PATH, GSON.toJson(config));
            }
        } catch (IOException | RuntimeException exception) {
            System.err.println("[Armour HUD] Could not load config: " + exception.getMessage());
        }
    }

    private static final class HudConfig {
        boolean enabled = true;
        // BOTH = remaining/max and percentage; NUMBER = remaining/max; PERCENT = percentage only.
        String displayMode = "BOTH";
        // HUD top-left position in scaled screen coordinates.
        int x = 8;
        int y = 8;
        // ARGB colours. Use decimal values in the JSON config.
        int textColor = -1;             // opaque white
        int backgroundColor = -1728053248; // translucent black
    }
}
