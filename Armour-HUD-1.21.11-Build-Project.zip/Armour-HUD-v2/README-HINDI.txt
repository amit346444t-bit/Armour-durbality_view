ARMOUR HUD v1.0.1 - SOURCE PROJECT
Target: Minecraft Java Edition 1.21.11 / Fabric / Java 21

IS VERSION MEIN KYA HAI
- Helmet, Chestplate, Leggings aur Boots durability.
- Elytra durability (chest slot mein Elytra pehni ho to alag label).
- Main hand item durability: sword, axe, pickaxe, shovel, hoe, bow, crossbow, trident, fishing rod aur koi bhi damageable item.
- Offhand item durability bhi, agar held item damageable ho.
- BOTH mode: remaining/max aur percentage, jaise 150/200 (75%).
- NUMBER mode: remaining/max.
- PERCENT mode: sirf percentage.
- HUD position, text colour, background colour aur enabled setting config file se customize kar sakte ho.

CONFIG
Game pehli baar launch hone par config/armourhud.json banegi.
Game band karke file ko text editor se edit karo:
{
  "enabled": true,
  "displayMode": "BOTH",
  "x": 8,
  "y": 8,
  "textColor": -1,
  "backgroundColor": -1728053248
}

displayMode: BOTH, NUMBER, ya PERCENT
x/y: HUD ki top-left position
textColor/backgroundColor: decimal ARGB colour values
Edit karne se pehle config ki backup copy rakhna.

BUILD
Required: JDK 21 and Gradle/Fabric Loom build environment.
Project folder mein command:
gradle build

Agar build successful ho, JAR build/libs/ mein milegi.

IMPORTANT
Yeh source project hai, compiled .jar nahi. Is environment mein Minecraft 1.21.11 ke against compile ya in-game test nahi hua hai. Isliye install-ready ya crash-free hone ki guarantee nahi di ja sakti. Pehle build karo, phir test instance mein try karo aur apni worlds ka backup rakho.
